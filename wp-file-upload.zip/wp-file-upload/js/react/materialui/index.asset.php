<?php return array('dependencies' => array('react', 'react-dom', 'wp-element'), 'version' => '7846b7de8c6194e94a71');
